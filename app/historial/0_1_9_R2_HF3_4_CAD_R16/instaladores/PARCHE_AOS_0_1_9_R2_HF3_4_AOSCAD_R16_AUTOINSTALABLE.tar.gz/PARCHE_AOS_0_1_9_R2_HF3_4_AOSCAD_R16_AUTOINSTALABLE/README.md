# Parche AOS 0.1.9 R2 HF3.4 + AOSCAD R16 (autoinstalable)

Integra **AOSCAD 0.0.1 DEV1 R16** (candidato a revision del jefe) sobre una
instalacion **AOS 0.1.9 R2 HF3.4** ya aplicada (Suite R3).

No modifica in-place el arbol R3 original. No reutiliza el parche CAD R16 de HF1.
Conserva geologia, GF3, punzados, AOS_app, AOSBCK y verifiers HF3.x.
Agrega overlay CAD R16: sync 2D/3D, recursos visuales, 3D Core, HYD_LOOP, ejemplos.

## Requisitos

- GNU Octave (probado con 11.3.0)
- Copia activa de **AOS 0.1.9 R2** con **HF3 / HF3.4**
  (`AOS_VERSION.txt` debe mencionar `0.1.9 R2` y `HF3`)
- **Windows o Linux**

## Instalacion

1. Extraer este paquete **fuera** de la carpeta AOS (o junto a ella).
   - Windows: descomprimir el `.zip`
   - Linux: `tar -xzf PARCHE_AOS_0_1_9_R2_HF3_4_AOSCAD_R16_AUTOINSTALABLE.tar.gz`
2. En GNU Octave, desde la carpeta del parche (con la raiz AOS en el path
   o como cwd padre):

```octave
clear functions
rehash
INSTALAR_PARCHE_AOS_0_1_9_R2_HF3_4_AOSCAD_R16
```

## Compatibilidad multiplataforma

Instalador y verificador en Octave puro (`fopen`/`fread`/`fwrite`, `fullfile`,
`exist`, `mkdir`), sin `system()` ni rutas absolutas. Payload de texto con LF.

Distribucion:

- `PARCHE_AOS_0_1_9_R2_HF3_4_AOSCAD_R16_AUTOINSTALABLE.zip`
- `PARCHE_AOS_0_1_9_R2_HF3_4_AOSCAD_R16_AUTOINSTALABLE.tar.gz`

## Que conserva (R3 / HF3.4)

- Geologia idempotente NaN / punzados HF3
- GF3 tubing libre + contrato espaciamiento HF3.4
- `AOS_app.m`, gestion de caso, utilidades HF2+
- AOSBCK R1 y entradas de menu asociadas
- Menu CAD opciones **9** (caso) y **10** (galerias)

## Que agrega (AOSCAD R16)

- Overlay `cad_topo`, `geometry_3d`, `units`, redes hidraulicas CAD
- Sync 2D/3D, traer STEP, invalidacion atomica, recursos visuales
- Menu union R16 + AOSBCK + 9/10
- Verifiers `VERIFICAR_AOSCAD_*` y ejemplos CAD con EOF

## Estado / promocion

- `AOSCAD`: `PROTOTIPO_NO_VALIDADO` / `DEV1` / `R16 CANDIDATO_REVISION_JEFE`
- **No se promociona a BETA**
- `DECISION_JEFE=PENDIENTE`
- Identidad suite: `0.1.9-R2-HF3.4-CAD-R16`

## Verificacion posterior

```octave
VERIFICAR_AOS_0_1_9_R2_HF3_4_AOSCAD_R16(false)
VERIFICAR_AOS_0_1_9_R2_HF3_4(false)
```

Prueba CAD ampliada:

```octave
VERIFICAR_AOS_0_1_9_R2_HF3_4_AOSCAD_R16(true)
```