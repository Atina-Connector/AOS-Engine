# Notas tecnicas — Parche HF3.4 + AOSCAD R16

## Estrategia

1. Sandbox desde R3 HF3.4 (sin tocar original).
2. Overlay CAD R16 (cad_topo, geometry_3d, units, redes, ejemplos, verifiers).
3. Union menu 9/10 + AOSBCK + sync R16.
4. Manifests por union; NO BETA CAD.
5. Gates HF3.4 + AOSCAD R16 verdes antes de empaquetar.
6. Payload = delta sandbox vs R3 limpio (blacklist suite/GF3/utilidades).

## No usar

Parche viejo `PARCHE_..._AOSCAD_R16` de R2_1/HF1: apunta a otra base.

## DECISION_JEFE

PENDIENTE