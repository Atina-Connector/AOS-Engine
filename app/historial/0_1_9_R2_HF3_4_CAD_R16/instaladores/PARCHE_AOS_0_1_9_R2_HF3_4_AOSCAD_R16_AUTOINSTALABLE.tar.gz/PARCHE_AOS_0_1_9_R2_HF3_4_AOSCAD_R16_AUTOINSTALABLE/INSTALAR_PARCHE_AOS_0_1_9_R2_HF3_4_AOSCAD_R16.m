function ok = INSTALAR_PARCHE_AOS_0_1_9_R2_HF3_4_AOSCAD_R16()
% INSTALAR_PARCHE_AOS_0_1_9_R2_HF3_4_AOSCAD_R16
% Integra AOSCAD R16 sobre AOS 0.1.9 R2 HF3.4 sin tocar geologia/GF3/AOS_app.

  ok = false;
  patch_dir = fileparts(mfilename('fullpath'));
  payload_dir = fullfile(patch_dir, 'payload');
  root = detectar_raiz_local(patch_dir);
  if isempty(root)
    error('No se encontro una raiz AOS valida.');
  endif

  version_file = fullfile(root, 'AOS_VERSION.txt');
  if exist(version_file, 'file') ~= 2
    error('La raiz seleccionada no contiene AOS_VERSION.txt.');
  endif
  version_txt = fileread(version_file);
  if isempty(strfind(version_txt, '0.1.9 R2'))
    error('Este parche requiere AOS 0.1.9 R2. Version detectada:\n%s', version_txt);
  endif
  if isempty(strfind(upper(version_txt), 'HF3'))
    error(['Este parche requiere HF3/HF3.4 aplicado. ' ...
      'No usar sobre R2 base ni sobre el parche CAD R16 de HF1.\n%s'], version_txt);
  endif

  stamp = datestr(now, 'yyyymmdd_HHMMSS');
  backup = fullfile(fileparts(root), ['backup_AOS_0_1_9_R2_HF3_4_AOSCAD_R16_' stamp]);
  asegurar_carpeta_local(backup);
  copiar = leer_lista_local(fullfile(patch_dir, 'PAYLOAD_FILES.txt'));
  nuevos = {};

  fprintf('\n================================================================\n');
  fprintf(' PARCHE AOS 0.1.9 R2 HF3.4 + AOSCAD R16\n');
  fprintf('================================================================\n');
  fprintf('Raiz AOS : %s\n', root);
  fprintf('Respaldo : %s\n', backup);
  fprintf('Archivos : %d\n', numel(copiar));

  try
    for i = 1:numel(copiar)
      rel = copiar{i};
      src = fullfile(payload_dir, rel);
      dst = fullfile(root, rel);
      if exist(src, 'file') ~= 2
        error('Falta archivo del payload: %s', rel);
      endif
      if exist(dst, 'file') == 2
        respaldar_local(dst, fullfile(backup, rel));
      else
        nuevos{end+1} = dst; %#ok<AGROW>
      endif
      copiar_archivo_local(src, dst);
      fprintf('INSTALADO  %s\n', rel);
    endfor

    addpath(root, '-begin');
    addpath(fullfile(root, 'src'), '-begin');
    clear functions;
    rehash();
    if exist('iniciar_aos', 'file') == 2
      iniciar_aos(true);
    endif

    resultado = VERIFICAR_AOS_0_1_9_R2_HF3_4_AOSCAD_R16(false);
    if isempty(resultado) || ~logical(resultado)
      error('La verificacion especifica HF3.4+AOSCAD R16 no fue aprobada.');
    endif

    if exist('VERIFICAR_AOS_0_1_9_R2_HF3_4', 'file') == 2
      r_hf = VERIFICAR_AOS_0_1_9_R2_HF3_4(false);
      if isempty(r_hf) || ~logical(r_hf)
        error('HF3.4 dejo de verificar tras el parche CAD.');
      endif
    endif

    ok = true;
    fprintf('\nPARCHE AOSCAD R16 SOBRE HF3.4 INSTALADO Y VERIFICADO.\n');
    fprintf('Version objetivo: 0.1.9-R2-HF3.4-CAD-R16\n');
    fprintf('AOSCAD permanece DEV1 / PROTOTIPO_NO_VALIDADO (sin BETA).\n');
    fprintf('DECISION_JEFE=PENDIENTE\n');
    fprintf('Prueba CAD completa: VERIFICAR_AOS_0_1_9_R2_HF3_4_AOSCAD_R16(true)\n');
  catch err
    fprintf(2, '\nERROR DE INSTALACION: %s\n', err.message);
    fprintf(2, 'Restaurando el estado anterior...\n');
    restaurar_local(root, backup, nuevos);
    rethrow(err);
  end_try_catch
endfunction

function root = detectar_raiz_local(patch_dir)
  root = '';

  activa = which('AOS_app');
  if ischar(activa) && ~isempty(activa)
    candidato = fileparts(fileparts(fileparts(activa)));
    if es_raiz_local(candidato)
      root = canon_local(candidato);
      return;
    endif
  endif

  candidatos = {pwd(), fileparts(patch_dir), fullfile(patch_dir, '..')};
  for i = 1:numel(candidatos)
    candidato = canon_local(candidatos{i});
    if es_raiz_local(candidato)
      root = candidato;
      return;
    endif
  endfor

  entrada = strtrim(input('Ruta de la carpeta raiz de AOS 0.1.9 R2 HF3.4: ', 's'));
  if es_raiz_local(entrada)
    root = canon_local(entrada);
  endif
endfunction

function tf = es_raiz_local(ruta)
  tf = ischar(ruta) && exist(fullfile(ruta, 'AOS.m'), 'file') == 2 && ...
    exist(fullfile(ruta, 'src'), 'dir') == 7 && ...
    exist(fullfile(ruta, 'AOS_VERSION.txt'), 'file') == 2;
endfunction

function lista = leer_lista_local(ruta)
  lista = {};
  fid = fopen(ruta, 'rt');
  if fid < 0
    error('No se pudo abrir %s', ruta);
  endif
  unwind_protect
    while true
      linea = fgetl(fid);
      if ~ischar(linea), break; endif
      linea = strtrim(linea);
      if ~isempty(linea) && linea(1) ~= '#'
        lista{end+1} = linea; %#ok<AGROW>
      endif
    endwhile
  unwind_protect_cleanup
    fclose(fid);
  end_unwind_protect
endfunction

function respaldar_local(origen, destino)
  copiar_archivo_local(origen, destino);
endfunction

function copiar_archivo_local(origen, destino)
  destino = strrep(char(destino), '/', filesep());
  origen = strrep(char(origen), '/', filesep());
  carpeta = fileparts(destino);
  asegurar_carpeta_local(carpeta);
  if exist(destino, 'file') == 2
    delete(destino);
  endif
  fid_in = fopen(origen, 'rb');
  if fid_in < 0
    error('No se pudo abrir origen %s', origen);
  endif
  unwind_protect
    bytes = fread(fid_in);
  unwind_protect_cleanup
    fclose(fid_in);
  end_unwind_protect
  fid_out = fopen(destino, 'wb');
  if fid_out < 0
    error('No se pudo crear destino %s', destino);
  endif
  unwind_protect
    fwrite(fid_out, bytes);
  unwind_protect_cleanup
    fclose(fid_out);
  end_unwind_protect
  if exist(destino, 'file') ~= 2
    error('Fallo al copiar %s -> %s', origen, destino);
  endif
endfunction

function asegurar_carpeta_local(carpeta)
  if isempty(carpeta), return; endif
  if exist(carpeta, 'dir') ~= 7
    [mk_ok, mk_msg] = mkdir(carpeta);
    if ~mk_ok && exist(carpeta, 'dir') ~= 7
      error('No se pudo crear %s (%s)', carpeta, mk_msg);
    endif
  endif
endfunction

function restaurar_local(root, backup, nuevos)
  for i = 1:numel(nuevos)
    if exist(nuevos{i}, 'file') == 2
      delete(nuevos{i});
    endif
  endfor
  restaurar_arbol_local(backup, root);
endfunction

function restaurar_arbol_local(origen, destino_root)
  if exist(origen, 'dir') ~= 7, return; endif
  d = dir(origen);
  for i = 1:numel(d)
    if strcmp(d(i).name, '.') || strcmp(d(i).name, '..'), continue; endif
    src = fullfile(origen, d(i).name);
    dst = fullfile(destino_root, d(i).name);
    if d(i).isdir
      restaurar_arbol_local(src, dst);
    else
      copiar_archivo_local(src, dst);
    endif
  endfor
endfunction

function p = canon_local(p)
  if isempty(p), return; endif
  try
    c = canonicalize_file_name(p);
    if ~isempty(c), p = c; endif
  catch
  end_try_catch
  p = strrep(char(p), '\\', '/');
  while numel(p) > 1 && p(end) == '/', p(end) = []; endwhile
endfunction
