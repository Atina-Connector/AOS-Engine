function ok = VERIFICAR_AOS_0_1_9_R2_HF3_3(profundo)
% Verifica HF3.3: correccion de signo de tubing libre en GF3.
  if nargin < 1, profundo = false; endif
  raiz = fileparts(mfilename('fullpath'));
  cd(raiz);
  addpath(raiz, '-begin');
  addpath(fullfile(raiz, 'src'), '-begin');
  iniciar_aos(true);

  fprintf('\n================================================================\n');
  fprintf(' VERIFICACION AOS 0.1.9 R2 HF3.3 - GF3 TUBERIA LIBRE\n');
  fprintf('================================================================\n');

  ok = VERIFICAR_GF3_SIGNO_TUBERIA_LIBRE_HF3_3(false);
  if profundo
    try
      r = VERIFICAR_AOS_0_1_9(true);
      ok = ok && logical(r);
    catch err
      fprintf(2, 'FALLO verificacion integral: %s\n', err.message);
      ok = false;
    end_try_catch
  endif

  if ok
    fprintf('RESULTADO: AOS 0.1.9 R2 HF3.3 APROBADO\n');
  else
    fprintf(2, 'RESULTADO: AOS 0.1.9 R2 HF3.3 NO APROBADO\n');
  endif
endfunction
