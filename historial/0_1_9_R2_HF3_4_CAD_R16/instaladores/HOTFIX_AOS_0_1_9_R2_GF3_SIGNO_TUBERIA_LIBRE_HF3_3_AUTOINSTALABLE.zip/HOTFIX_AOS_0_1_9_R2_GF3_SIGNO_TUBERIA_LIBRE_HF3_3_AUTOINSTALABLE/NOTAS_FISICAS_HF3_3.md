# Notas físicas HF3.3

GF3 utiliza desplazamiento axial positivo hacia arriba. Una tubería libre que
se elonga desplaza su extremo inferior hacia abajo:

```text
ΔL_tubing >= 0
u_fondo_tubing = -ΔL_tubing
```

La posición relativa del pistón dentro del barril es:

```text
u_rel = u_varilla_fondo - u_fondo_tubing
```

Durante una transferencia elástica aislada:

```text
F = (E*A/L) * ΔL_tubing
```

por lo que la pendiente de carga frente a posición pistón-barril debe ser
positiva. El selftest `test_gf3_signo_tuberia_libre_hf3_3` verifica además que
la rigidez observada coincida con `E*A/L` y que el caso de tubería anclada
permanezca en cero.

La magnitud `x_tuberia_m` se mantiene por compatibilidad y significa elongación
positiva. El nuevo campo `u_fondo_m` es la posición firmada del barril.
