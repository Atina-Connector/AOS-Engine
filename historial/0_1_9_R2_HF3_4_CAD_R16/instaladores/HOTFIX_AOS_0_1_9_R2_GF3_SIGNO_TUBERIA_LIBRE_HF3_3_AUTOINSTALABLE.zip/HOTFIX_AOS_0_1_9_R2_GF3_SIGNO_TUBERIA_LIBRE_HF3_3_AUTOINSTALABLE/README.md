# Hotfix AOS 0.1.9 R2 HF3.3

## GF3: signo físico de tubería libre

Este hotfix corrige la regresión observada en la carta de fondo de Bombeo
Mecánico con tubería libre. La versión HF3.2 confundía la elongación positiva
del tubing con la posición axial firmada del barril y producía una rama de
transferencia con pendiente invertida.

La convención restaurada es:

```text
elongación tubing >= 0
u_barril = -elongación tubing
u_pistón-barril = u_varilla_fondo - u_barril
dF / d(u_pistón-barril) = E*A/L > 0
```

`x_tuberia_m` se conserva como alias histórico de elongación positiva. El
cálculo de espaciamiento usa esa magnitud y no la posición firmada del barril.

## Base requerida

```text
AOS Suite 0.1.9 R2 HF3.2
```

No debe aplicarse sobre R1, HF1, HF2, HF3 o HF3.1. Para esos casos se entrega
una distribución completa HF3.3.

## Instalación

Extraer el ZIP fuera de la carpeta AOS. Desde GNU Octave, entrar en la carpeta
extraída y ejecutar:

```octave
clear functions
rehash
INSTALAR_HOTFIX_AOS_0_1_9_R2_GF3_SIGNO_TUBERIA_LIBRE_HF3_3
```

Después, desde la raíz AOS:

```octave
clear functions
rehash
VERIFICAR_AOS_0_1_9_R2_HF3_3(false)
VERIFICAR_AOS_0_1_9_R2_HF3_3(true)
```

## Repetición del caso

Los gráficos anteriores fueron construidos con la convención incorrecta. Debe
ejecutarse nuevamente la corrida BM y regenerar `.aosrpt`, imágenes y archivos
de exportación. El hotfix también puede reparar un resultado residente para
consulta, sin volver a integrar las cargas, pero no debe reutilizarse una figura
antigua como evidencia de la corrida corregida.

## Alcance físico

No se modifican:

- integración axial de la sarta;
- cargas de superficie y bomba;
- lógica de válvulas;
- carta de superficie;
- LPP;
- diseño de sarta y barras de peso.

Se modifica solamente la cinemática relativa pistón-barril asociada al
movimiento elástico del tubing libre y los campos derivados de esa convención.
