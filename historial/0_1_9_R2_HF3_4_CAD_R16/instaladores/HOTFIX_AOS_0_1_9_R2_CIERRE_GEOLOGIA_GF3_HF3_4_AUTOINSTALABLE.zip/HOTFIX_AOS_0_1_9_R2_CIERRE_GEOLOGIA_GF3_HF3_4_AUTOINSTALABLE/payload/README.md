# AOS Suite 0.1.9 R2 HF3.4

**Puerta de entrada a AOS 0.2.0 - Distribucion completa para GNU Octave**

AOS 0.1.9 R2 consolida la arquitectura por bancos de trabajo de R1 y restaura,
sin eliminar funciones anteriores, la gestion transversal de casos, la prioridad
operativa del `.aosdat`, los catalogos y las galerias.

Esta entrega es una **version completa**, no un parche.

## Inicio

```octave
cd('/ruta/AOS_0_1_9_R2')
clear functions
rehash
VERIFICAR_AOS_0_1_9_R2(false)
AOS
```

Verificacion funcional ampliada:

```octave
VERIFICAR_AOS_0_1_9_R2(true)
```

## Correcciones consolidadas en R2

- Opcion transversal `NUEVO / ABRIR / IMPORTAR / CONFIGURAR CASO` en la Suite.
- Apertura e importacion contextual dentro de SLA, BM, GL/JGL, BES, PCP, CGF,
  EGF, Wells, CAD, Networks, Electrical, Facilities, Geology, Fluids, SCADA y
  Maintenance.
- El `.aosdat` activo mantiene prioridad sobre los defaults de `config/`.
- Catalogos base, permanentes del usuario y embebidos en `.aosdat`.
- Contrato simetrico `AOS_CATALOGO_R2` para bombas, valvulas, varillas y
  unidades de bombeo mecanico.
- Ejemplo completo: `datos/ejemplos/catalogos/AOS_CATALOGO_R2_DEMO.aosdat`.
- Importacion de catalogos puros sin reemplazar el caso activo.
- Galeria de mandriles `[MANDRILES_GALERIA]` y galerias CAD/DXF.
- BES3 nuevamente visible desde el banco BES, conservando el estado
  `DESARROLLO_NO_VALIDADO`.
- Verificador semantico por registro, entrypoint y despacho; no depende de la
  numeracion visual del menu.
- Limpieza AOSBCK no interactiva y restringida a directorios temporales.
- Path operativo controlado, sin `genpath` indiscriminado y sin tests/legacy en
  la ejecucion normal.
- Unica interfaz publica de requisitos CAD, sin funciones sombreadas.
- Exportacion STEP con candidatos FreeCAD silenciosos y temporales unicos.

## Bancos de trabajo

AOS SLA, Wells, CAD, Networks, Electrical, Facilities, Geology, Fluids, SCADA,
Maintenance, Data, Solvers, Global y Viewer. Los bancos planificados siguen
visibles para alimentar el futuro frame con cinta de AOS 0.2.0.

## Formatos principales

- `.aosdat`: configuracion y modelo de caso.
- `.aosrpt`: reporte de simulacion AOS.
- `.aoscad`: reporte editable y recalculable de AOSCAD.
- `.aosbck`: componente 3D reutilizable derivado de STEP.
- DXF/STEP: fuentes externas de geometria.

## Historial R1

La distribucion original R1 se conserva como archivo independiente e inmutable:

- `AOS_0_1_9_R1_HISTORICO.zip`
- SHA-256: `7032b765346828bb26dc8ceada580dbe3fc6166ff879db427b361d5fc6637cb3`

Consulte `historial/AOS_0_1_9_R1_BASELINE.md`,
`historial/R1/README_ARCHIVO_HISTORICO_R1.md` y
`HISTORIAL_DESARROLLO_AOS_0_1_9_R1.md`.

## Estado de validacion

R2 no cambia ecuaciones ni correlaciones fisicas. Conserva el estado de madurez
de cada banco y solver. La distribucion incluye verificadores y selftests; la
validacion dinamica oficial debe ejecutarse en GNU Octave mediante
`VERIFICAR_AOS_0_1_9_R2(true)`.

## AOS 0.1.9 R2 HF1

HF1 corrige la apertura de la gestion transversal del caso cuando la
configuracion activa no tiene nombre y el grupo `pozo` es una estructura.
Ver `CHANGELOG_AOS_0_1_9_R2_HF1.md` y ejecutar:

```octave
VERIFICAR_AOS_0_1_9_R2_HF1(false)
```

## AOS 0.1.9 R2 HF2

HF2 incorpora la auditoria transversal de interacciones y conversiones. Corrige
la administracion ambigua de geologia, el round-trip de vectores de catalogos,
la preservacion de elementos deshabilitados en galerias y la estabilidad del
path durante campañas de selftests. Tambien estandariza todas las preguntas
binarias activas mediante `aos_preguntar_sn` y elimina el uso de `str2num`.

Verificacion especifica:

```octave
VERIFICAR_AOS_0_1_9_R2_HF2(false)
```

Campana completa:

```octave
VERIFICAR_AOS_0_1_9_R2_HF2(true)
```

## AOS 0.1.9 R2 HF3 - gestor de punzados

HF3 restaura la administracion manual y completa de los intervalos de
punzados. El acceso principal es:

```text
AOS Suite -> AOS Wells -> Survey, punzados y completacion
          -> ADMINISTRAR / GENERAR PUNZADOS
```

La misma pantalla es accesible desde AOS Data, Geology, herramientas comunes
de SLA, BES3 y la gestion universal del caso.

Los punzados pueden configurarse sin Survey ni geologia. Si existe Survey,
AOS calcula TVD como dato derivado. Los archivos `.aosdat` conservan el bloque
historico `[PUNZADOS]` y agregan `[PUNZADOS_META]` para los datos extendidos.

Verificacion:

```octave
VERIFICAR_AOS_0_1_9_R2_HF3(false)
VERIFICAR_AOS_0_1_9_R2_HF3(true)
```

## AOS 0.1.9 R2 HF3.1 - cierre de dependencias

HF3.1 sustituye al hotfix HF3 original. Corrige el empaquetado de las utilidades
transversales requeridas por el gestor de punzados y verifica su ruta efectiva
antes de ejecutar los selftests.

```octave
VERIFICAR_AOS_0_1_9_R2_HF3_1(false)
VERIFICAR_AOS_0_1_9_R2_HF3_1(true)
```

## AOS 0.1.9 R2 HF3.2 - cierre de auditoria

HF3.2 corrige el cierre de la auditoria transversal cuando no existen
hallazgos y restablece el alias `n_salida` del contrato de resolucion de
punzados geologicos, conservando tambien `n_finales`.

```octave
VERIFICAR_AOS_0_1_9_R2_HF3_2(false)
VERIFICAR_AOS_0_1_9_R2_HF3_2(true)
```


## AOS 0.1.9 R2 HF3.3 - signo de tubing libre en GF3

HF3.3 corrige una regresion fisica en la carta de fondo de Bombeo Mecanico:
la elongacion positiva del tubing ya no se confunde con la posicion axial
firmada del barril. El spacing conserva la magnitud positiva y los resultados
residentes pueden repararse sin modificar las cargas del solver.

```octave
VERIFICAR_AOS_0_1_9_R2_HF3_3(false)
VERIFICAR_AOS_0_1_9_R2_HF3_3(true)
```


## HF3.4 - cierre de campaña dinámica

HF3.4 corrige dos contratos detectados por la verificación completa:

- la comparación de geología usa `isequaln`, evitando invalidaciones ficticias por campos `NaN`;
- GF3 unifica `valido`/`valido_calculo` y `validacion`/`mensaje_validacion` en el resultado de espaciamiento.

Verificación recomendada:

```octave
VERIFICAR_AOS_0_1_9_R2_HF3_4(false)
VERIFICAR_AOS_0_1_9_R2_HF3_4(true)
```
