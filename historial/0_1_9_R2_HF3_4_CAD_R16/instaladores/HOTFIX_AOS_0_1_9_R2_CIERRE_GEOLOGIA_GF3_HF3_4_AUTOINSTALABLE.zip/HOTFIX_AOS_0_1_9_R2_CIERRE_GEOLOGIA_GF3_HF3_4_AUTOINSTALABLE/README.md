# Hotfix AOS 0.1.9 R2 HF3.4

## Cierre de campaña: geología idempotente y contrato GF3

La campaña dinámica de HF3.3 confirmó que la corrección del signo de tubería
libre quedó aprobada. El rechazo global restante provino de dos contratos:

1. reconfirmar una geología idéntica con campos `NaN` se interpretaba como un
   cambio y volvía a invalidar resultados;
2. el productor de espaciamiento GF3 publicaba `valido`/`validacion`, mientras
   el validador y el reporte consumían `valido_calculo`/`mensaje_validacion`.

HF3.4 corrige ambos puntos sin modificar ecuaciones ni resultados físicos.

## Base requerida

```text
AOS Suite 0.1.9 R2 HF3.3
```

## Instalación

Extraer el ZIP fuera de la carpeta AOS. Desde GNU Octave, entrar en la carpeta
extraída y ejecutar:

```octave
clear functions
rehash
INSTALAR_HOTFIX_AOS_0_1_9_R2_CIERRE_GEOLOGIA_GF3_HF3_4
```

Después, desde la raíz AOS:

```octave
clear functions
rehash
VERIFICAR_AOS_0_1_9_R2_HF3_4(false)
VERIFICAR_AOS_0_1_9_R2_HF3_4(true)
```

## Alcance

- `aos_geologia_commit` utiliza una comparación compatible con `NaN`.
- GF3 publica los dos pares de nombres de campo por compatibilidad.
- Los resultados residentes se migran sin recalcular valores físicos.
- El validador y el contexto de reportes aceptan contratos históricos y nuevos.
- El selftest integral GF3 muestra el detalle de cualquier rechazo.

HF3.4 conserva íntegramente la corrección física de tubería libre de HF3.3.
