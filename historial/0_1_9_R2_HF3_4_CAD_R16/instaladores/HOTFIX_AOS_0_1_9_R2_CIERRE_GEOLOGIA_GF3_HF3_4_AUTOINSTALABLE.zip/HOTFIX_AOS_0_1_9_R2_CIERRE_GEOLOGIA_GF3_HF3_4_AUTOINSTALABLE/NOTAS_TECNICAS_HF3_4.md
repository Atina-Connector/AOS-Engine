# Notas técnicas HF3.4

## Geología

`isequal` considera distintos dos valores `NaN`. Los punzados normalizados
contienen campos opcionales `NaN`, por lo que una reconfirmación idéntica
producía `cambio=true`. HF3.4 utiliza `isequaln` después de retirar campos de
auditoría, haciendo el commit idempotente.

## GF3

El cálculo de espaciamiento ya producía un resultado finito, pero existía una
incompatibilidad de nombres entre productor y consumidores:

```text
productor:  valido / validacion
consumidor: valido_calculo / mensaje_validacion
```

HF3.4 publica y migra ambos pares. `geometria_aprobada` continúa siendo una
condición independiente; no se redefine la aprobación física.

## Regresiones

- `test_aos_geologia_idempotencia_hf3_4`
- `test_gf3_contrato_espaciamiento_hf3_4`
- `test_aos_geologia_transaccional_hf2`
- `gibbs3_selftest`
