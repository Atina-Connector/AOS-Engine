function archivo = sens_exportar_resultados(nombre_variable, titulo, param, sistema)
% AOS_0_1_0_SENSIBILIDADES_TABLAS_TEXTO_NATIVO
% SENS_EXPORTAR_RESULTADOS Exportador comun y auditable de sensibilidades.
% GNU Octave. Contrato AOSRPT 1.6 para AOS Viewer.
%
% Reglas:
%   - Nunca serializa estructuras internas completas.
%   - El Viewer recibe solo unidades de usuario: bar, m, m3/d, Sm3/d, Hz.
%   - Cada punto se escribe como una fila de [SENSITIVITY_TABLE].
%   - Las tablas se serializan como texto y datos nativos, nunca como PNG.
%   - El enriquecido captura solo graficos reales de la sensibilidad y agrega
%     imagenes independientes de survey y punzados.
  archivo = '';
  if nargin < 4 || isempty(sistema), sistema = 'SENSIBILIDAD'; end
  if nargin < 3 || isempty(param), param = struct(); end
  if evalin('base', sprintf("exist('%s','var')", nombre_variable)) ~= 1
    fprintf('ADVERTENCIA: no se encontro %s; no se puede exportar.\n', nombre_variable);
    return;
  end
  datos = evalin('base', nombre_variable);
  paquete = sens_construir_paquete(datos, titulo, sistema);

  fprintf('\n--- EXPORTAR RESULTADOS DE SENSIBILIDAD ---\n');
  fprintf('1 - .aosrpt ligero (tabla completa + ganancias)\n');
  fprintf('2 - .aosrpt enriquecido (tabla textual + graficos + survey + punzados)\n');
  fprintf('3 - CSV\n');
  fprintf('0 - No exportar\n');
  op = input('Seleccione una opcion [0]: ');
  if isempty(op), op = 0; end
  if ~ismember(op,[0 1 2 3]), fprintf('Opcion invalida. No se exporta.\n'); return; end
  if op == 0, return; end

  carpeta_defecto = fullfile('intercambio','reportes','enviados');
  carpeta = aos_report_choose_directory(carpeta_defecto);
  base_nombre = regexprep([aos_nombre_pozo_local(param) '_' regexprep(lower(titulo),'[^a-zA-Z0-9]+','_')], '_+$','');
  ext = '.aosrpt'; if op == 3, ext = '.csv'; end
  fprintf('Nombre propuesto: %s%s\n', base_nombre, ext);
  nuevo = strtrim(input(sprintf('Nombre del archivo sin extension [%s]: ',base_nombre),'s'));
  if ~isempty(nuevo), base_nombre = regexprep(nuevo,'\.(aosrpt|csv)$',''); end
  archivo = fullfile(carpeta,[base_nombre ext]);

  if op == 3
    sens_escribir_csv(archivo, paquete);
    fprintf('CSV exportado: %s\n', archivo);
    return;
  end

  incluir = aos_preguntar_sn('Incluir survey, tubing, punzados y equipo de fondo? (s/n) [s]: ',true);
  sens_escribir_aosrpt(archivo, titulo, sistema, paquete, param, incluir, op==2);
  if exist('aos_finalizar_archivo_crypto','file') == 2
    aos_finalizar_archivo_crypto(archivo,true);
  else
    fprintf('ADVERTENCIA: modulo crypto no disponible; archivo guardado en texto plano.\n');
  end
  fprintf('Reporte exportado: %s\n', archivo);
end

function sens_escribir_aosrpt(archivo,titulo,sistema,p,param,incluir,enriquecido)
  tabla=tabla_nativa_local(p,titulo);
  tabla.role='SENSITIVITY_TABLE';tabla.category='SENSITIVITY';tabla.priority='PRIMARY';
  tabla.default_mode='FULL_BODY';tabla.mandatory=true;tabla.source='AOS_SENSITIVITY_SOLVER';
  [param,tablas,comp]=aos_report_prepare_tables(param,sistema,tabla,struct());
  n_graficos=0;
  if enriquecido&&exist('aos_registro_graficos','file')==2
    try,r=aos_registro_graficos('list');n_graficos=numel(r);catch,n_graficos=0;end_try_catch
  endif
  fid=fopen(archivo,'w');if fid<0,error('No se pudo crear %s',archivo);endif
  c=onCleanup(@() fclose(fid));
  fprintf(fid,'[AOS_REPORT]\nversion=1.7\nviewer_schema=AOS_VIEWER_SENSITIVITY_1.3\n');
  fprintf(fid,'fecha=%s\nsistema=%s\nmodulo=SENSIBILIDAD\n',datestr(now,'yyyy-mm-dd HH:MM:SS'),sistema);
  fprintf(fid,'titulo=%s\nnombre_pozo=%s\n',limpiar_txt(titulo),aos_nombre_pozo_local(param));
  fprintf(fid,'formato=%s\ncontract_revision=AOSRPT_TABLES_1.1\n',cond(enriquecido,'ENRIQUECIDO','LIGERO'));
  [~,rid,~]=fileparts(archivo);mi=struct('report_id',rid,'report_type',[regexprep(upper(sistema),'[^A-Z0-9_-]+','_') '_SENSITIVITY'], ...
    'module',regexprep(upper(sistema),'[^A-Z0-9_-]+','_'),'workbench','AOS_SLA','viewer_schema','AOS_VIEWER_SENSITIVITY_1.3','graphics_count',n_graficos);
  aos_report_write_manifest(fid,mi,comp);

  fprintf(fid,'\n[SENSITIVITY_SUMMARY]\nvariable=%s\nunidad_variable=%s\nmetodo=%s\nn_puntos=%d\n',p.variable,p.unidad_variable,p.metodo,p.n);
  if p.n>0,xv=p.columnas{1};fprintf(fid,'rango_min=%.10g\nrango_max=%.10g\n',min_finito(xv),max_finito(xv));endif
  fprintf(fid,'puntos_aceptados=%d\npuntos_rechazados=%d\nconfianza_global=%s\nclasificacion_principal=%s\nmensaje=%s\n',sum(p.aceptado),sum(~p.aceptado),p.confianza_global,p.clasificacion_principal,limpiar_txt(p.mensaje));
  fprintf(fid,'tabla_punto_a_punto=SI\ntable_id=%s\nrender_mode=%s\n',tablas(1).id,tablas(1).render_mode);
  if isfinite(p.referencia_variable),fprintf(fid,'referencia_variable=%.10g\nreferencia_tipo=%s\n',p.referencia_variable,p.referencia_tipo);endif
  if ~isempty(p.ganancias)
    for ig=1:numel(p.ganancias),gg=p.ganancias(ig);clave=campo_seguro_local(gg.respuesta);fprintf(fid,'ganancia_%s_base=%.10g\n',clave,gg.valor_base);if isfinite(gg.ganancia_max_pct),fprintf(fid,'ganancia_%s_max_pct=%.10g\nganancia_%s_variable_max=%.10g\n',clave,gg.ganancia_max_pct,clave,gg.variable_ganancia_max);endif,endfor
  endif
  diag=aos_sensibilidad_diagnosticar(p,sistema,param);aos_rpt_escribir_diagnostico(fid,diag);
  aos_rpt_escribir_tablas(fid,tablas,comp);
  aos_report_write_reference(fid,'SENSITIVITY_TABLE',tablas(1),'DISPONIBLE');
  sens_escribir_resumen_ganancias(fid,p);
  sens_escribir_clasificacion(fid,'JGL',p.clasificacion_JGL,p);
  sens_escribir_clasificacion(fid,'GL',p.clasificacion_GL,p);
  sens_escribir_clasificacion(fid,'BES',p.clasificacion_BES,p);
  if exist('aos_exportar_contexto_viewer','file')==2,aos_exportar_contexto_viewer(fid,param,sistema,incluir);endif
  if enriquecido
    if incluir,aos_rpt_exportar_graficos_sensibilidad(fid,p,param,sistema,archivo);else,aos_rpt_exportar_graficos_sensibilidad(fid,p,struct(),sistema,archivo);endif
  endif
end

function p=sens_construir_paquete(d,titulo,sistema)
  p=struct('variable','PARAMETRO','unidad_variable','-', 'metodo','NO_INFORMADO',...
    'n',0,'nombres',{{}},'unidades',{{}},'columnas',{{}},'aceptado',[],...
    'confianza_global','NO_EVALUADA','clasificacion_principal','NO_EVALUADA',...
    'mensaje','Sin clasificacion','clasificacion_JGL',struct(),...
    'clasificacion_GL',struct(),'clasificacion_BES',struct(),...
    'ganancias',struct([]),'referencia_variable',NaN,...
    'referencia_tipo','NO_DEFINIDA');

  % Variable independiente y unidad visible.
  [x,xname,xunit]=sens_variable_independiente(d,titulo);
  p.variable=xname; p.unidad_variable=xunit; p.n=numel(x);
  p=sens_add_col(p,xname,xunit,x);

  % Columnas canonicas, primero las ya expresadas en unidades de usuario.
  p=add_top(p,d,{'Ql_JGL_m3d','Qo_JGL_m3d','Ql_GL_m3d','Qo_GL_m3d',...
    'P_s_bar','P_req_bar','DeltaP_bar','iteraciones','a_eductor','b_eductor',...
    'P_compresor_kW','P_hidraulica_JGL_kW','P_hidraulica_GL_kW',...
    'Indice_energetico_bruto_JGL_pct','Indice_energetico_bruto_GL_pct',...
    'Eficiencia_interna_jet_JGL_pct','rendimiento_energetico_JGL_pct',...
    'rendimiento_energetico_GL_pct','rendimiento_energetico_pct',...
    'Eficiencia_JGL_pct','Eficiencia_GL_pct','P_transferida_kW','P_disponible_kW',...
    'solicitado_bar','efectivo_bar','solicitado_Hz','efectivo_Hz',...
    'solicitado_m','efectivo_m'},p.n);

  % Las respuestas genericas se renombran segun el sistema para evitar
  % columnas duplicadas y conservar semantica en Viewer/CSV.
  ql_generico=get_vec(d,'Ql_m3d',p.n); qo_generico=get_vec(d,'Qo_m3d',p.n);
  modo_generico=first_cell({get_cell(d,'modos',p.n),get_cell(d,'modo',p.n)},p.n);
  estado_generico=first_cell({get_cell(d,'estados',p.n),get_cell(d,'estado',p.n)},p.n);
  if strcmpi(sistema,'JGL')
    p=add_num(p,'Ql_JGL_m3d','m3/d',ql_generico,p.n);
    p=add_num(p,'Qo_JGL_m3d','m3/d',qo_generico,p.n);
    p=add_cell(p,'Modo_JGL','-',modo_generico,p.n);
    p=add_cell(p,'Estado_JGL','-',estado_generico,p.n);
  elseif strcmpi(sistema,'GL')
    p=add_num(p,'Ql_GL_m3d','m3/d',ql_generico,p.n);
    p=add_num(p,'Qo_GL_m3d','m3/d',qo_generico,p.n);
    p=add_cell(p,'Estado_GL','-',estado_generico,p.n);
  else
    p=add_num(p,'Ql_m3d','m3/d',ql_generico,p.n);
    p=add_num(p,'Qo_m3d','m3/d',qo_generico,p.n);
    p=add_cell(p,'Modo','-',modo_generico,p.n);
    p=add_cell(p,'Estado','-',estado_generico,p.n);
  endif
  if ~strcmpi(p.variable,'Qiny')
    p=add_num(p,'Qiny_Sm3_d','Sm3/d',get_vec(d,'Qiny_Sm3_d',p.n),p.n);
  endif
  p=add_num(p,'Qiny_efectivo_Sm3_d','Sm3/d',get_vec(d,'Qiny_efectivo',p.n)*86400,p.n);
  p=add_num(p,'Qg_formacion_Sm3_d','Sm3/d',get_vec(d,'Qg_formacion',p.n)*86400,p.n);
  p=add_num(p,'Qg_total_VLP_Sm3_d','Sm3/d',get_vec(d,'Qg_total_VLP',p.n)*86400,p.n);

  % Resultado JGL/GL anidado usado por las sensibilidades actuales.
  R=get_struct(d,'resultado');
  J=get_struct(R,'jgl');
  p=add_num(p,'Ql_JGL_m3d','m3/d',get_vec(R,'Ql_JGL',p.n)*86400,p.n);
  p=add_num(p,'Qo_JGL_m3d','m3/d',get_vec(R,'Qo_JGL',p.n)*86400,p.n);
  p=add_num(p,'Ql_GL_m3d','m3/d',get_vec(R,'Ql_GL',p.n)*86400,p.n);
  p=add_num(p,'Qo_GL_m3d','m3/d',get_vec(R,'Qo_GL',p.n)*86400,p.n);
  p=add_num(p,'Qiny_JGL_Sm3_d','Sm3/d',get_vec(J,'qiny_efectivo',p.n)*86400,p.n);
  p=add_num(p,'Qiny_GL_Sm3_d','Sm3/d',get_vec(R,'qiny_efectivo_GL',p.n)*86400,p.n);
  p=add_num(p,'DeltaP_JGL_bar','bar',first_vec({get_vec(R,'deltaP_JGL',p.n),get_vec(J,'deltaP',p.n)},p.n)*1e-5,p.n);
  p=add_num(p,'Iteraciones_JGL','-',first_vec({get_vec(R,'iteraciones_JGL',p.n),get_vec(J,'iteraciones',p.n)},p.n),p.n);
  p=add_cell(p,'Modo_JGL','-',first_cell({get_cell(R,'modos_JGL',p.n),get_cell(J,'modos',p.n)},p.n),p.n);
  p=add_cell(p,'Estado_JGL','-',first_cell({get_cell(R,'estados_JGL',p.n),get_cell(J,'estados',p.n)},p.n),p.n);
  p=add_cell(p,'Estado_GL','-',first_cell({get_cell(R,'estados_GL',p.n),get_cell(R,'estado_GL',p.n)},p.n),p.n);
  p=add_num(p,'Qg_formacion_GL_Sm3_d','Sm3/d',get_vec(R,'Qg_formacion_GL',p.n)*86400,p.n);
  p=add_num(p,'Qg_total_VLP_GL_Sm3_d','Sm3/d',get_vec(R,'Qg_total_VLP_GL',p.n)*86400,p.n);
  p=add_num(p,'P_req_GL_bar','bar',get_vec(R,'P_req_GL',p.n)*1e-5,p.n);
  p=add_num(p,'P_s_GL_bar','bar',get_vec(R,'P_s_GL',p.n)*1e-5,p.n);
  err=first_vec({get_vec(R,'error_directo_iterativo',p.n),get_vec(J,'error_directo_iterativo',p.n)},p.n);
  p=add_num(p,'Error_Directo_Iterativo_pct','%',100*err,p.n);
  p=add_num(p,'Verificado_Iterativo','-',first_vec({get_vec(R,'seleccion_iterativa',p.n),get_vec(J,'seleccion_iterativa',p.n)},p.n),p.n);

  % Sensibilidades JGL puras: resultado puede contener soluciones celda.
  RJ=get_struct(d,'resultado');
  sols=get_cell(RJ,'soluciones',p.n);
  if ~isempty(sols)
    [ql,qo,dp,it,mo,es,er,qe]=extraer_soluciones(sols,p.n);
    p=add_num(p,'Ql_JGL_m3d','m3/d',ql,p.n);
    p=add_num(p,'Qo_JGL_m3d','m3/d',qo,p.n);
    p=add_num(p,'Qiny_JGL_Sm3_d','Sm3/d',qe,p.n);
    p=add_num(p,'DeltaP_JGL_bar','bar',dp,p.n);
    p=add_num(p,'Iteraciones_JGL','-',it,p.n);
    p=add_cell(p,'Modo_JGL','-',mo,p.n);
    p=add_cell(p,'Estado_JGL','-',es,p.n);
    p=add_num(p,'Error_Directo_Iterativo_pct','%',er,p.n);
  end

  % BES: extraer resultados por punto sin exponer estructuras.
  rb=get_cell(d,'resultados',p.n);
  if ~isempty(rb)
    [ql,qo,pint,tmot,corr,rl,estado]=extraer_bes(rb,p.n);
    p=add_num(p,'Ql_m3d','m3/d',ql,p.n); p=add_num(p,'Qo_m3d','m3/d',qo,p.n);
    p=add_num(p,'P_intake_bar','bar',pint,p.n); p=add_num(p,'T_motor_C','C',tmot,p.n);
    p=add_num(p,'Corriente_A','A',corr,p.n); p=add_num(p,'RunLife_d','d',rl,p.n);
    p=add_cell(p,'Estado','-',estado,p.n);
  end

  % Estado/aceptacion y confianza por punto.
  estado=buscar_col_cell(p,{'Estado_JGL','Estado'});
  estado_gl=buscar_col_cell(p,{'Estado_GL'});
  err=buscar_col_num(p,{'Error_Directo_Iterativo_pct'});
  acept=true(1,p.n); conf=repmat({'ALTA'},1,p.n);
  for i=1:p.n
    e=''; if ~isempty(estado),e=upper(estado{i});end
    eg=''; if ~isempty(estado_gl),eg=upper(estado_gl{i});end
    if ~isempty(strfind(e,'NO_CONVERGE'))||~isempty(strfind(e,'ERROR'))||~isempty(strfind(e,'INVALID'))|| ...
       ~isempty(strfind(eg,'NO_CONVERGE'))||~isempty(strfind(eg,'ERROR'))||~isempty(strfind(eg,'INVALID'))
      acept(i)=false;conf{i}='BAJA';
    elseif ~isempty(err)&&isfinite(err(i))&&err(i)>10
      acept(i)=false;conf{i}='BAJA';
    elseif ~isempty(err)&&isfinite(err(i))&&err(i)>5
      conf{i}='MEDIA';
    elseif ~isempty(err)&&~isfinite(err(i))
      conf{i}='NO_EVALUADA';
    end
  end
  p.aceptado=acept;
  p=sens_add_col(p,'Aceptado','-',num2cell_si_no(acept));
  p=sens_add_col(p,'Confianza','-',conf);
  if any(~acept),p.confianza_global='MEDIA';else,p.confianza_global='ALTA';end
  if all(cellfun(@(s)strcmp(s,'NO_EVALUADA'),conf)),p.confianza_global='NO_EVALUADA';end

  p=sens_agregar_ganancias(p,d);

  p.metodo=detectar_metodo(d,R,J,sistema);
  p.clasificacion_JGL=get_struct(d,'clasificacion_JGL');
  p.clasificacion_GL=get_struct(d,'clasificacion_GL');
  p.clasificacion_BES=get_struct(d,'clasificacion');
  [p.clasificacion_principal,p.mensaje]=clasificacion_texto(p);
end

function [x,n,u]=sens_variable_independiente(d,titulo)
  if isfield(d,'Qiny'),x=d.Qiny*86400;n='Qiny';u='Sm3/d';return;end
  if isfield(d,'Qiny_Sm3_d'),x=d.Qiny_Sm3_d;n='Qiny';u='Sm3/d';return;end
  if isfield(d,'Qiny_solicitado'),x=d.Qiny_solicitado*86400;n='Qiny';u='Sm3/d';return;end
  if isfield(d,'qiny_solicitado'),x=d.qiny_solicitado*86400;n='Qiny';u='Sm3/d';return;end
  if isfield(d,'Piny_Pa'),x=d.Piny_Pa*1e-5;n='Piny';u='bar';return;end
  if isfield(d,'Pwh_Pa'),x=d.Pwh_Pa*1e-5;n='Pwh';u='bar';return;end
  if isfield(d,'Diny_m'),x=d.Diny_m;n='Profundidad_inyeccion';u='m';return;end
  if isfield(d,'A_n_mm2'),x=d.A_n_mm2;n='Area_tobera';u='mm2';return;end
  if isfield(d,'d_t_mm'),x=d.d_t_mm;n='Diametro_garganta';u='mm';return;end
  if isfield(d,'solicitado_bar'),x=d.solicitado_bar;n='Pwh';u='bar';return;end
  if isfield(d,'solicitado_Hz'),x=d.solicitado_Hz;n='Frecuencia';u='Hz';return;end
  if isfield(d,'solicitado_m'),x=d.solicitado_m;n='Profundidad';u='m';return;end
  if isfield(d,'solicitado'),x=d.solicitado;n='Parametro';u='-';return;end
  f=fieldnames(d);x=[];
  for k=1:numel(f),v=d.(f{k});if isnumeric(v)&&isvector(v)&&numel(v)>1,x=v;n=f{k};u='-';return;end,end
  x=0;n=regexprep(titulo,'[^A-Za-z0-9]','_');u='-';
end

function p=add_top(p,d,names,n)
  for k=1:numel(names)
    f=names{k};if isfield(d,f)&&isnumeric(d.(f))&&isvector(d.(f))&&numel(d.(f))==n
      [nm,un]=nombre_unidad(f);p=add_num(p,nm,un,d.(f),n);
    end
  end
end
function [n,u]=nombre_unidad(f)
  n=f;u='-';lf=lower(f);
  if ~isempty(strfind(lf,'pct'))
    u='%';
  elseif ~isempty(strfind(lf,'m3d'))
    u='m3/d';
  elseif ~isempty(strfind(lf,'bar'))
    u='bar';
  elseif ~isempty(strfind(lf,'hz'))
    u='Hz';
  elseif ~isempty(strfind(lf,'_m'))
    u='m';
  endif
endfunction
function p=add_num(p,n,u,v,N)
  if isempty(v)||numel(v)~=N||any(strcmp(p.nombres,n)),return;end
  p=sens_add_col(p,n,u,double(v(:)'));
end
function p=add_cell(p,n,u,v,N)
  if isempty(v)||numel(v)~=N||any(strcmp(p.nombres,n)),return;end
  p=sens_add_col(p,n,u,v(:)');
end
function p=sens_add_col(p,n,u,v)
  p.nombres{end+1}=n;p.unidades{end+1}=u;p.columnas{end+1}=v;
end

function [ql,qo,dp,it,mo,es,er,qe]=extraer_soluciones(c,N)
  ql=nan(1,N);qo=ql;dp=ql;it=ql;er=ql;qe=ql;mo=repmat({''},1,N);es=mo;
  for i=1:N
    s=c{i};if ~isstruct(s),continue;end
    ql(i)=numfield(s,{'Ql'},NaN)*86400;qo(i)=numfield(s,{'Qo'},NaN)*86400;
    dp(i)=numfield(s,{'deltaP','DeltaP'},NaN)*1e-5;it(i)=numfield(s,{'iteraciones'},NaN);
    er(i)=100*numfield(s,{'error_directo_iterativo'},NaN);qe(i)=numfield(s,{'Qiny','qiny_efectivo'},NaN)*86400;
    mo{i}=txtfield(s,{'modo_utilizado','modo'},'');es{i}=txtfield(s,{'estado'},'');
  end
end
function [ql,qo,pint,tmot,corr,rl,estado]=extraer_bes(c,N)
  ql=nan(1,N);qo=ql;pint=ql;tmot=ql;corr=ql;rl=ql;estado=repmat({''},1,N);
  for i=1:N
    s=c{i};if ~isstruct(s),continue;end
    ql(i)=numfield(s,{'Ql'},NaN)*86400;qo(i)=numfield(s,{'Qo'},NaN)*86400;
    pint(i)=numfield(s,{'P_intake'},NaN)*1e-5;tmot(i)=numfield(s,{'T_motor'},NaN);
    corr(i)=numfield(s,{'corriente'},NaN);rl(i)=numfield(s,{'run_life'},NaN);estado{i}=txtfield(s,{'estado'},'');
  end
end
function s=get_struct(a,f),s=struct();if isstruct(a)&&isfield(a,f)&&isstruct(a.(f)),s=a.(f);end,end
function v=get_vec(a,f,N),v=[];if isstruct(a)&&isfield(a,f)&&isnumeric(a.(f))&&isvector(a.(f))&&numel(a.(f))==N,v=double(a.(f)(:))';end,end
function c=get_cell(a,f,N),c={};if isstruct(a)&&isfield(a,f)&&iscell(a.(f))&&isvector(a.(f))&&numel(a.(f))==N,c=a.(f)(:)';end,end
function v=first_vec(C,N),v=[];for i=1:numel(C),if ~isempty(C{i})&&numel(C{i})==N,v=C{i};return;end,end,end
function c=first_cell(C,N),c={};for i=1:numel(C),if ~isempty(C{i})&&numel(C{i})==N,c=C{i};return;end,end,end
function v=numfield(s,fs,d),v=d;for k=1:numel(fs),if isfield(s,fs{k})&&isnumeric(s.(fs{k}))&&isscalar(s.(fs{k})),v=s.(fs{k});return;end,end,end
function v=txtfield(s,fs,d),v=d;for k=1:numel(fs),if isfield(s,fs{k})&&ischar(s.(fs{k})),v=s.(fs{k});return;end,end,end
function c=buscar_col_cell(p,names),c={};for k=1:numel(names),i=find(strcmp(p.nombres,names{k}),1);if ~isempty(i)&&iscell(p.columnas{i}),c=p.columnas{i};return;end,end,end
function v=buscar_col_num(p,names),v=[];for k=1:numel(names),i=find(strcmp(p.nombres,names{k}),1);if ~isempty(i)&&isnumeric(p.columnas{i}),v=p.columnas{i};return;end,end,end
function c=num2cell_si_no(v),c=cell(1,numel(v));for i=1:numel(v),if v(i),c{i}='SI';else,c{i}='NO';end,end,end

function m=detectar_metodo(d,R,J,sistema)
  m='NO_INFORMADO';
  c={txtfield(d,{'modo_solicitado','metodo'},''),txtfield(R,{'modo_solicitado'},''),txtfield(J,{'modo_solicitado'},'')};
  for k=1:numel(c),if ~isempty(c{k}),m=upper(c{k});return;end,end
  if strcmpi(sistema,'BES'),m='SOLVER_BES';end
end
function [t,msg]=clasificacion_texto(p)
  S={p.clasificacion_JGL,p.clasificacion_GL,p.clasificacion_BES};t='NO_EVALUADA';msg='Sin clasificacion';
  for k=1:numel(S)
    s=S{k};if isstruct(s)&&~isempty(fieldnames(s))
      t=txtfield(s,{'tipo'},'NO_EVALUADA');msg=txtfield(s,{'mensaje'},t);return;
    end
  end
end
function sens_escribir_clasificacion(fid,nombre,s,p)
  if ~isstruct(s)||isempty(fieldnames(s)),return;end
  fprintf(fid,'\n[CLASSIFICATION_%s]\n',nombre);
  fprintf(fid,'tipo=%s\n',txtfield(s,{'tipo'},'NO_EVALUADA'));
  fprintf(fid,'mensaje=%s\n',limpiar_txt(txtfield(s,{'mensaje'},'')));
  ox=numfield(s,{'optimo_x'},NaN);oy=numfield(s,{'optimo_y'},NaN);
  if isfinite(ox)
    if strcmp(p.unidad_variable,'Sm3/d')&&abs(ox)<100,ox=ox*86400;end
    if strcmp(p.unidad_variable,'bar')&&abs(ox)>1e4,ox=ox*1e-5;end
    fprintf(fid,'optimo_variable=%.10g\n',ox);fprintf(fid,'unidad_optimo_variable=%s\n',p.unidad_variable);
  end
  if isfinite(oy),fprintf(fid,'optimo_respuesta=%.10g\n',oy);end
end

% Las figuras enriquecidas se exportan exclusivamente mediante el registro
% transversal aos_registro_graficos. No se aplica limite fijo ni deduplicacion
% por titulo en este exportador numerico.

function sens_escribir_csv(archivo,p)
  fid=fopen(archivo,'w');if fid<0,error('No se pudo crear CSV');end;c=onCleanup(@()fclose(fid));
  fprintf(fid,'%s\n',strjoin(p.nombres,','));
  fprintf(fid,'%s\n',strjoin(p.unidades,','));
  for i=1:p.n
    vals=cell(1,numel(p.columnas));for j=1:numel(p.columnas),v=p.columnas{j};if iscell(v),vals{j}=csv_inline(v{i});else,vals{j}=num_inline(v(i));end,end
    fprintf(fid,'%s\n',strjoin(vals,','));
  end
end
function s=num_inline(v),if ~isfinite(v),s='';else,s=sprintf('%.12g',v);end,end
function s=csv_inline(x),if ~ischar(x),x='';end;x=strrep(x,'"','""');s=['"' x '"'];end
function s=limpiar_txt(x),if ~ischar(x),x='';end;s=regexprep(x,'[\r\n=]',' ');end
function b=leer_base64(a),f=fopen(a,'rb');if f<0,b='';return;end;bytes=fread(f,Inf,'uint8=>uint8');fclose(f);b=base64_encode(bytes);end
function n=aos_nombre_pozo_local(p)
  n='pozo';campos={'nombre_pozo','pozo','nombre','archivo_aosdat'};
  for i=1:numel(campos)
    if isstruct(p)&&isfield(p,campos{i})&&ischar(p.(campos{i}))&&~isempty(strtrim(p.(campos{i})))
      n=p.(campos{i});break;
    end
  end
  global AOSDAT_ACTIVO;
  if strcmp(n,'pozo') && ischar(AOSDAT_ACTIVO) && ~isempty(AOSDAT_ACTIVO),n=AOSDAT_ACTIVO;end
  [~,base,ext]=fileparts(n);if ~isempty(base),n=base;elseif ~isempty(ext),n=[base ext];end
  n=regexprep(n,'[^a-zA-Z0-9_-]','_');n=regexprep(n,'_+','_');n=regexprep(n,'^_+|_+$','');
  if isempty(n),n='pozo';end
end

function t=tabla_nativa_local(p,titulo)
  t=struct();t.id='sensibilidad_001';t.title=limpiar_txt(titulo);
  t.schema='AOS_NATIVE_TABLE_1.1';t.section='SENSIBILIDAD';t.role='SENSITIVITY_TABLE';
  t.category='SENSITIVITY';t.priority='PRIMARY';t.default_mode='FULL_BODY';t.mandatory=true;
  t.columns=p.nombres;t.labels=p.nombres;
  t.units=p.unidades;t.rows=cell(p.n,numel(p.nombres));
  t.types=cell(1,numel(p.nombres));t.precision=cell(1,numel(p.nombres));
  for j=1:numel(p.nombres)
    v=p.columnas{j};
    if iscell(v),t.types{j}='text';t.precision{j}='';
    else,t.types{j}='number';t.precision{j}='6';end
    for i=1:p.n
      if iscell(v),t.rows{i,j}=v{i};else,t.rows{i,j}=v(i);end
    end
  end
end

function v=min_finito(x),y=x(isfinite(x));if isempty(y),v=NaN;else,v=min(y);end,end
function v=max_finito(x),y=x(isfinite(x));if isempty(y),v=NaN;else,v=max(y);end,end

function p=sens_agregar_ganancias(p,d)
  if p.n <= 0 || isempty(p.columnas)
    return;
  endif
  x=p.columnas{1};
  preferir_cero=strcmpi(p.variable,'Qiny');
  candidatos={'Ql_JGL_m3d','Qo_JGL_m3d','Ql_GL_m3d','Qo_GL_m3d','Ql_m3d','Qo_m3d'};
  ganancias=struct('respuesta',{},'unidad',{},'indice_referencia',{},...
    'variable_referencia',{},'valor_base',{},'tipo_referencia',{},...
    'porcentaje_calculable',{},'ganancia_max_pct',{},...
    'variable_ganancia_max',{},'valor_max',{});
  refs=[];
  tipos={};
  for k=1:numel(candidatos)
    nombre=candidatos{k};
    idx=find(strcmp(p.nombres,nombre),1);
    if isempty(idx) || ~isnumeric(p.columnas{idx})
      continue;
    endif
    y=p.columnas{idx};
    [ga,gp,gi,info]=sens_calcular_ganancias(y,x,preferir_cero);
    base=regexprep(nombre,'_m3d$','');
    p=add_num(p,['Ganancia_' base '_m3d'],'m3/d',ga,p.n);
    p=add_num(p,['Ganancia_' base '_pct'],'%',gp,p.n);
    p=add_num(p,['Ganancia_incremental_' base '_pct'],'%',gi,p.n);
    g=struct();
    g.respuesta=nombre;g.unidad='m3/d';g.indice_referencia=info.indice;
    g.variable_referencia=info.x;g.valor_base=info.base;g.tipo_referencia=info.tipo;
    g.porcentaje_calculable=info.porcentaje_calculable;
    [g.ganancia_max_pct,g.variable_ganancia_max,g.valor_max]=maximo_ganancia_local(gp,x,y,p.aceptado);
    ganancias(end+1)=g;
    if isfinite(info.x),refs(end+1)=info.x;tipos{end+1}=info.tipo;endif
  endfor
  p.ganancias=ganancias;
  if ~isempty(refs)
    p.referencia_variable=refs(1);
    p.referencia_tipo=tipos{1};
  elseif isstruct(d) && isfield(d,'referencia_ganancia') && ischar(d.referencia_ganancia)
    p.referencia_tipo=d.referencia_ganancia;
  endif
endfunction

function [gmax,xmax,ymax]=maximo_ganancia_local(g,x,y,aceptado)
  gmax=NaN;xmax=NaN;ymax=NaN;
  ok=isfinite(g)&isfinite(x)&isfinite(y);
  if nargin>=4 && numel(aceptado)==numel(ok)
    ok=ok&logical(aceptado);
  endif
  ids=find(ok);
  if isempty(ids),return;endif
  [gmax,j]=max(g(ids));i=ids(j);xmax=x(i);ymax=y(i);
endfunction

function sens_escribir_resumen_ganancias(fid,p)
  fprintf(fid,'\n[SENSITIVITY_GAIN_SUMMARY]\n');
  fprintf(fid,'schema=AOS_SENSITIVITY_GAIN_1.0\n');
  fprintf(fid,'n_respuestas=%d\n',numel(p.ganancias));
  fprintf(fid,'referencia_tipo=%s\n',p.referencia_tipo);
  if isfinite(p.referencia_variable)
    fprintf(fid,'referencia_variable=%.10g\n',p.referencia_variable);
    fprintf(fid,'referencia_unidad=%s\n',p.unidad_variable);
  endif
  for i=1:numel(p.ganancias)
    g=p.ganancias(i);
    fprintf(fid,'respuesta_%02d=%s\n',i,g.respuesta);
    fprintf(fid,'respuesta_%02d_valor_base=%.10g\n',i,g.valor_base);
    fprintf(fid,'respuesta_%02d_indice_referencia=%.0f\n',i,g.indice_referencia);
    fprintf(fid,'respuesta_%02d_tipo_referencia=%s\n',i,g.tipo_referencia);
    fprintf(fid,'respuesta_%02d_pct_calculable=%s\n',i,cond(g.porcentaje_calculable,'SI','NO'));
    if isfinite(g.ganancia_max_pct)
      fprintf(fid,'respuesta_%02d_ganancia_max_pct=%.10g\n',i,g.ganancia_max_pct);
      fprintf(fid,'respuesta_%02d_variable_ganancia_max=%.10g\n',i,g.variable_ganancia_max);
      fprintf(fid,'respuesta_%02d_valor_max=%.10g\n',i,g.valor_max);
    endif
  endfor
endfunction

function sens_escribir_resultados_texto_nativo(fid,p)
% Escribe una tabla humana en una seccion estandar de resultados.
% Esta seccion es texto real del .aosrpt: puede copiarse, buscarse y
% reconstruirse sin rasterizar informacion numerica.
  fprintf(fid,'\n[RESULTADOS]\n');
  fprintf(fid,'tipo_resultado=SENSIBILIDAD\n');
  fprintf(fid,'variable_sensibilizada=%s\n',limpiar_txt(p.variable));
  fprintf(fid,'unidad_variable=%s\n',limpiar_txt(p.unidad_variable));
  fprintf(fid,'numero_puntos=%d\n',p.n);
  fprintf(fid,'formato_tabla=TEXTO_NATIVO\n');
  fprintf(fid,'tabla_imagen=NO\n');
  fprintf(fid,'tabla_titulo=Produccion y resultados punto a punto\n');
  [idx,nombres]=columnas_principales_local(p,10);
  fprintf(fid,'tabla_columnas=%s\n',limpiar_txt(strjoin(nombres,' | ')));
  fprintf(fid,'tabla_unidades=%s\n',limpiar_txt(strjoin(p.unidades(idx),' | ')));
  for i=1:p.n
    vals=cell(1,numel(idx));
    for k=1:numel(idx)
      v=p.columnas{idx(k)};
      if iscell(v)
        vals{k}=texto_corto_local(v{i},24);
      else
        vals{k}=num_inline(v(i));
      endif
    endfor
    fprintf(fid,'punto_%03d=%s\n',i,limpiar_txt(strjoin(vals,' | ')));
  endfor
  if ~isempty(p.ganancias)
    fprintf(fid,'ganancia_referencia_tipo=%s\n',limpiar_txt(p.referencia_tipo));
    if isfinite(p.referencia_variable)
      fprintf(fid,'ganancia_referencia_variable=%.10g\n',p.referencia_variable);
    endif
    for i=1:numel(p.ganancias)
      g=p.ganancias(i);
      clave=campo_seguro_local(g.respuesta);
      fprintf(fid,'ganancia_%s_base=%.10g\n',clave,g.valor_base);
      if isfinite(g.ganancia_max_pct)
        fprintf(fid,'ganancia_%s_max_pct=%.10g\n',clave,g.ganancia_max_pct);
        fprintf(fid,'ganancia_%s_variable_max=%.10g\n',clave,g.variable_ganancia_max);
      endif
    endfor
  endif
endfunction

function sens_escribir_datos_compatibles(fid,p)
  fprintf(fid,'\n[SENSITIVITY_DATA]\n');
  fprintf(fid,'schema=AOS_SENSITIVITY_VECTORS_1.0\n');
  fprintf(fid,'nota=Compatibilidad con Viewer previo; la fuente canonica es SENSITIVITY_TABLE.\n');
  for j=1:numel(p.columnas)
    clave=campo_seguro_local(p.nombres{j});
    v=p.columnas{j};
    vals=cell(1,p.n);
    for i=1:p.n
      if iscell(v),vals{i}=vector_txt_local(v{i});else,vals{i}=num_inline(v(i));endif
    endfor
    fprintf(fid,'%s=%s\n',clave,strjoin(vals,','));
    fprintf(fid,'%s_unidad=%s\n',clave,limpiar_txt(p.unidades{j}));
  endfor
endfunction

function sens_escribir_tabla_texto(fid,p)
  fprintf(fid,'\n[SENSITIVITY_TABLE_TEXT]\n');
  fprintf(fid,'schema=AOS_SENSITIVITY_TEXT_1.1\n');
  fprintf(fid,'render_mode=TEXT_NATIVE\n');
  fprintf(fid,'image_ref=NONE\n');
  [idx,nombres]=columnas_principales_local(p,10);
  encabezado=strjoin(nombres,' | ');
  fprintf(fid,'encabezado=%s\n',limpiar_txt(encabezado));
  fprintf(fid,'unidades=%s\n',limpiar_txt(strjoin(p.unidades(idx),' | ')));
  for i=1:p.n
    vals=cell(1,numel(idx));
    for k=1:numel(idx)
      v=p.columnas{idx(k)};
      if iscell(v),vals{k}=texto_corto_local(v{i},18);else,vals{k}=num_inline(v(i));endif
    endfor
    fprintf(fid,'fila_%03d=%s\n',i,limpiar_txt(strjoin(vals,' | ')));
  endfor
endfunction

function [idx,nombres]=columnas_principales_local(p,maxn)
  prioridad={p.variable,'Ql_JGL_m3d','Ganancia_Ql_JGL_pct','Qo_JGL_m3d',...
    'Ganancia_Qo_JGL_pct','Ql_GL_m3d','Ganancia_Ql_GL_pct','Qo_GL_m3d',...
    'Ganancia_Qo_GL_pct','Ql_m3d','Ganancia_Ql_pct','Qo_m3d',...
    'Ganancia_Qo_pct','Indice_energetico_bruto_JGL_pct',...
    'Eficiencia_interna_jet_JGL_pct','Indice_energetico_bruto_GL_pct',...
    'DeltaP_JGL_bar','Iteraciones_JGL','Estado_JGL',...
    'Estado_GL','Estado','Aceptado','Confianza'};
  idx=[];
  for i=1:numel(prioridad)
    j=find(strcmp(p.nombres,prioridad{i}),1);
    if ~isempty(j)&&~any(idx==j),idx(end+1)=j;endif
    if numel(idx)>=maxn,break;endif
  endfor
  if isempty(idx),idx=1:min(maxn,numel(p.nombres));endif
  nombres=p.nombres(idx);
endfunction

function s=campo_seguro_local(x)
  if ~ischar(x),x='campo';endif
  s=regexprep(x,'[^A-Za-z0-9_]+','_');
  s=regexprep(s,'^_+|_+$','');
  if isempty(s),s='campo';endif
endfunction

function s=vector_txt_local(x)
  if ~ischar(x),x='';endif
  x=strrep(x,',',';');x=strrep(x,'=','-');x=regexprep(x,'[\r\n]',' ');
  s=['"' strrep(x,'"','""') '"'];
endfunction

function s=texto_corto_local(x,n)
  if ~ischar(x),x='';endif
  x=regexprep(x,'[\r\n|=]',' ');
  if numel(x)>n,x=[x(1:max(1,n-3)) '...'];endif
  s=x;
endfunction

function s=cond(c,a,b),if c,s=a;else,s=b;end,end
