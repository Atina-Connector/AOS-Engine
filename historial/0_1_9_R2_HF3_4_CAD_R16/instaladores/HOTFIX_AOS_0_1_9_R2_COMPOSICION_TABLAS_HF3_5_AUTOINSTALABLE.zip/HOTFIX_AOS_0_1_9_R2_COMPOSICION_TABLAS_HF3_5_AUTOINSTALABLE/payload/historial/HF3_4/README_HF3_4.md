# AOS 0.1.9 R2 HF3.4

Baseline inmediata de HF3.5. HF3.4 cerro la idempotencia geologica y el
contrato publico de espaciamiento GF3. HF3.5 conserva esas correcciones y agrega
exclusivamente la composicion transversal de tablas y los contratos de reporte.
