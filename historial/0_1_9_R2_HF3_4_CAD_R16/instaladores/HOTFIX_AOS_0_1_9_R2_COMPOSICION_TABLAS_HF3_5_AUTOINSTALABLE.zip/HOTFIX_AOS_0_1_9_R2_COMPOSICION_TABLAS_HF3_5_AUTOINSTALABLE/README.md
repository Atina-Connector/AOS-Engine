# Hotfix AOS 0.1.9 R2 HF3.5

## Composicion transversal de tablas

HF3.5 incorpora una capa comun para todos los modulos, sensibilidades,
disenos y comparaciones que generan reportes con tablas.

La simulacion conserva todos los datos. Al exportar, el usuario elige:

- perfil Ejecutivo;
- perfil Tecnico;
- Auditoria completa;
- Personalizado, con decision tabla por tabla.

Cada tabla puede quedar completa en el cuerpo, resumida, muestreada, completa
en anexo, solo disponible para datos/Viewer o excluida de esa salida visible.
Ocultarla nunca borra sus filas.

Las tablas de sensibilidad se consideran resultado primario y se proponen
completas en todos los perfiles.

## Base requerida

```text
AOS Suite 0.1.9 R2 HF3.4
```

## Instalacion

Extraer el ZIP fuera de la carpeta AOS. Desde GNU Octave, entrar en la carpeta
extraida y ejecutar:

```octave
clear functions
rehash
INSTALAR_HOTFIX_AOS_0_1_9_R2_COMPOSICION_TABLAS_HF3_5
```

Despues, desde la raiz AOS:

```octave
clear functions
rehash
VERIFICAR_AOS_0_1_9_R2_HF3_5(false)
VERIFICAR_AOS_0_1_9_R2_HF3_5(true)
```

## Cobertura

- reportes genericos simple y enriquecido;
- BM/GF3;
- BES V2 y BES3;
- comparacion BES3;
- CGF y EGF;
- mandriles;
- sensibilidades historicas y transversales;
- AOSCAD;
- importacion y consulta de tablas nativas.

## AOS Viewer

HF3.5 escribe `TABLE_INDEX` para las tablas visibles y
`TABLE_ARCHIVE_INDEX` para las tablas completas que no deben ocupar paginas.
El equipo del Viewer debe validar el consumo del nuevo contrato. Los reportes
anteriores permanecen legibles.
