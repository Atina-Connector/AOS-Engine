# Notas tecnicas HF3.5

## Contrato

- `AOS_REPORT_MANIFEST_1.1`
- `AOS_REPORT_COMPOSITION_1.0`
- `AOS_NATIVE_TABLE_1.1`
- `AOS_TABLE_ARCHIVE_1.0`

## Politica

`full_data_policy=ALWAYS_PRESERVE`

`VIEWER_ONLY` y `EXCLUDED_EXPORT` controlan la presentacion, no la retencion.
`SUMMARY` y `SAMPLED` generan una vista compacta y archivan la tabla completa.

## Extensibilidad

Un modulo actual o futuro puede entregar tablas por:

```octave
param.aosrpt_tablas
contexto.report_tables
```

sin implementar otro menu de seleccion.

## Limitacion de validacion

El entorno de construccion no contiene GNU Octave. Se realizaron auditoria
estatica, control de dependencias, comparacion de arboles y verificacion de
integridad. La campana dinamica se cierra en la instalacion del usuario.
