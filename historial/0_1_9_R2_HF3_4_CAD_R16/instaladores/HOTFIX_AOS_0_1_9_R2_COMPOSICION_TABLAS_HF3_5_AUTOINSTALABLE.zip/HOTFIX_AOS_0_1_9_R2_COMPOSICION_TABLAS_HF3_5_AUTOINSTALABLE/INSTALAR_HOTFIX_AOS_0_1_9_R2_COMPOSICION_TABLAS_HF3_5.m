function ok = INSTALAR_HOTFIX_AOS_0_1_9_R2_COMPOSICION_TABLAS_HF3_5()
% Instala AOS 0.1.9 R2 HF3.5 sobre HF3.4.
% Composicion transversal de tablas para todos los reportes AOS.
% Motor cientifico oficial: GNU Octave.

  ok = false;
  patch_dir = fileparts(mfilename('fullpath'));
  payload_dir = fullfile(patch_dir, 'payload');
  root = detectar_raiz_local(patch_dir);
  if isempty(root)
    error('No se encontro una raiz AOS valida.');
  endif

  version_file = fullfile(root, 'AOS_VERSION.txt');
  if exist(version_file, 'file') ~= 2
    error('La raiz no contiene AOS_VERSION.txt.');
  endif
  version_txt = fileread(version_file);
  es_hf34 = ~isempty(strfind(version_txt, 'AOS Suite 0.1.9 R2 HF3.4'));
  es_hf35 = ~isempty(strfind(version_txt, 'AOS Suite 0.1.9 R2 HF3.5'));

  if es_hf35
    fprintf('AOS 0.1.9 R2 HF3.5 ya esta instalado. Ejecutando verificacion.\n');
    preparar_path_local(root);
    ok = VERIFICAR_AOS_0_1_9_R2_HF3_5(false);
    return;
  endif
  if ~es_hf34
    error(['HF3.5 requiere AOS 0.1.9 R2 HF3.4. ' ...
      'Version detectada:\n%s'], version_txt);
  endif

  copiar = leer_lista_local(fullfile(patch_dir, 'PAYLOAD_FILES.txt'));
  verificar_payload_local(payload_dir, ...
    fullfile(patch_dir, 'SHA256SUMS_PAYLOAD.txt'), copiar);
  verificar_baseline_local(root, ...
    fullfile(patch_dir, 'BASELINE_CRITICAL_SHA256.txt'));

  stamp = datestr(now, 'yyyymmdd_HHMMSS');
  backup = fullfile(fileparts(root), ...
    ['backup_AOS_0_1_9_R2_HF3_5_' stamp]);
  asegurar_carpeta_local(backup);
  nuevos = {};

  fprintf('\n================================================================\n');
  fprintf(' AOS 0.1.9 R2 HF3.5 - COMPOSICION TRANSVERSAL DE TABLAS\n');
  fprintf('================================================================\n');
  fprintf('Raiz AOS : %s\n', root);
  fprintf('Respaldo : %s\n', backup);
  fprintf('Archivos : %d\n', numel(copiar));

  try
    for i = 1:numel(copiar)
      rel = copiar{i};
      src = fullfile(payload_dir, rel);
      dst = fullfile(root, rel);
      if exist(src, 'file') ~= 2
        error('Falta archivo del payload: %s', rel);
      endif
      if exist(dst, 'file') == 2
        respaldar_local(dst, fullfile(backup, rel));
      else
        nuevos{end+1} = dst;
      endif
      asegurar_carpeta_local(fileparts(dst));
      [cp_ok, cp_msg] = copyfile(src, dst, 'f');
      if ~cp_ok
        error('No se pudo instalar %s (%s)', rel, cp_msg);
      endif
      fprintf('INSTALADO  %s\n', rel);
    endfor

    limpiar_cache_local();
    preparar_path_local(root);
    verificar_resolucion_local(root);

    resultado = VERIFICAR_AOS_0_1_9_R2_HF3_5(false);
    if isempty(resultado) || ~logical(resultado)
      error('La verificacion focalizada HF3.5 no fue aprobada.');
    endif

    ok = true;
    fprintf('\nHF3.5 INSTALADO Y VERIFICADO.\n');
    fprintf('Campana integral recomendada:\n');
    fprintf('  clear functions; rehash; ');
    fprintf('VERIFICAR_AOS_0_1_9_R2_HF3_5(true)\n');
  catch err
    fprintf(2, '\nERROR DE INSTALACION: %s\n', err.message);
    fprintf(2, 'Restaurando AOS 0.1.9 R2 HF3.4...\n');
    restaurar_local(root, backup, nuevos, copiar);
    try
      limpiar_cache_local();
      preparar_path_local(root);
    catch
    end_try_catch
    rethrow(err);
  end_try_catch
endfunction

function root = detectar_raiz_local(patch_dir)
  root = '';
  activa = which('AOS_app');
  if ischar(activa) && ~isempty(activa)
    candidato = fileparts(fileparts(fileparts(activa)));
    if es_raiz_local(candidato)
      root = canon_local(candidato);
      return;
    endif
  endif
  aos_activo = which('AOS');
  if ischar(aos_activo) && ~isempty(aos_activo)
    candidato = fileparts(aos_activo);
    if es_raiz_local(candidato)
      root = canon_local(candidato);
      return;
    endif
  endif
  candidatos = {pwd(), fileparts(patch_dir), fullfile(patch_dir, '..')};
  for i = 1:numel(candidatos)
    candidato = canon_local(candidatos{i});
    if es_raiz_local(candidato)
      root = candidato;
      return;
    endif
  endfor
  entrada = strtrim(input('Ruta de la carpeta raiz AOS 0.1.9 R2 HF3.4: ', 's'));
  if es_raiz_local(entrada)
    root = canon_local(entrada);
  endif
endfunction

function tf = es_raiz_local(ruta)
  tf = ischar(ruta) && ...
    exist(fullfile(ruta, 'AOS.m'), 'file') == 2 && ...
    exist(fullfile(ruta, 'src'), 'dir') == 7 && ...
    exist(fullfile(ruta, 'AOS_VERSION.txt'), 'file') == 2;
endfunction

function preparar_path_local(root)
  addpath(root, '-begin');
  addpath(fullfile(root, 'src'), '-begin');
  iniciar_aos(true);
  rehash();
endfunction

function limpiar_cache_local()
  clear aos_report_configure_tables aos_report_apply_profile;
  clear aos_report_prepare_tables aos_report_write_manifest;
  clear aos_report_parse_native_tables aos_report_print_native_tables;
  clear aos_rpt_escribir_tablas aos_report_dispatcher;
  clear gibbs3_report_build_tables bes2_report_build_tables;
  clear bes3_report_build_tables cgf_report_build_tables;
  clear aos_aoscad_report_composition;
  clear test_aos_report_composition_hf3_5;
  clear test_aos_report_module_tables_hf3_5;
  clear test_aos_report_sensitivity_hf3_5;
  clear test_aos_aoscad_report_composition_hf3_5;
  clear test_aos_report_coverage_hf3_5;
  clear VERIFICAR_AOS_0_1_9 VERIFICAR_AOS_0_1_9_R2_HF3_5;
  clear AOS_app;
  rehash();
endfunction

function verificar_resolucion_local(root)
  nombres = { ...
    'aos_report_configure_tables', ...
    'aos_report_apply_profile', ...
    'aos_report_prepare_tables', ...
    'aos_report_write_manifest', ...
    'aos_report_parse_native_tables', ...
    'aos_report_print_native_tables', ...
    'aos_rpt_escribir_tablas', ...
    'gibbs3_report_build_tables', ...
    'bes2_report_build_tables', ...
    'bes3_report_build_tables', ...
    'cgf_report_build_tables', ...
    'aos_aoscad_report_composition', ...
    'VERIFICAR_AOS_0_1_9_R2_HF3_5'};
  raiz_canon = [canon_local(root) '/'];
  for i = 1:numel(nombres)
    ruta = which(nombres{i});
    if ~ischar(ruta) || isempty(ruta)
      error('Funcion HF3.5 no localizada: %s', nombres{i});
    endif
    ruta_canon = canon_local(ruta);
    if numel(ruta_canon) < numel(raiz_canon) || ...
        ~strncmp(ruta_canon, raiz_canon, numel(raiz_canon))
      error('Funcion %s resuelta fuera de la raiz activa: %s', ...
        nombres{i}, ruta);
    endif
    fprintf('RUTA OK     %-44s %s\n', nombres{i}, ruta);
  endfor
endfunction

function verificar_baseline_local(root, hash_file)
  esperados = leer_hashes_local(hash_file);
  campos = fieldnames(esperados);
  for i = 1:numel(campos)
    item = esperados.(campos{i});
    ruta = fullfile(root, item.rel);
    if exist(ruta, 'file') ~= 2
      error('Falta archivo critico de HF3.4: %s', item.rel);
    endif
    real = sha256_archivo_local(ruta);
    if ~strcmpi(real, item.hash)
      error(['El archivo critico %s no coincide con HF3.4. ' ...
        'Use la distribucion completa HF3.5 o revise cambios locales.'], item.rel);
    endif
  endfor
  fprintf('OK  baseline critica HF3.4 verificada: %d archivo(s).\n', numel(campos));
endfunction

function verificar_payload_local(payload_dir, hash_file, lista)
  esperados = leer_hashes_local(hash_file);
  for i = 1:numel(lista)
    rel = lista{i};
    ruta = fullfile(payload_dir, rel);
    clave = sanitizar_hash_local(rel);
    if ~isfield(esperados, clave)
      error('No existe SHA-256 declarado para %s.', rel);
    endif
    real = sha256_archivo_local(ruta);
    esperado = esperados.(clave).hash;
    if ~strcmpi(real, esperado)
      error('SHA-256 invalido para %s.', rel);
    endif
  endfor
  fprintf('OK  integridad del payload: %d archivo(s).\n', numel(lista));
endfunction

function mapa = leer_hashes_local(ruta)
  mapa = struct();
  fid = fopen(ruta, 'rt');
  if fid < 0, error('No se pudo abrir %s', ruta); endif
  unwind_protect
    while true
      linea = fgetl(fid);
      if ~ischar(linea), break; endif
      tok = regexp(linea, '^([0-9A-Fa-f]{64})[ ]{2}(.+)$', ...
        'tokens', 'once');
      if isempty(tok), continue; endif
      rel = strtrim(tok{2});
      clave = sanitizar_hash_local(rel);
      mapa.(clave) = struct('hash', lower(tok{1}), 'rel', rel);
    endwhile
  unwind_protect_cleanup
    fclose(fid);
  end_unwind_protect
endfunction

function h = sha256_archivo_local(ruta)
  fid = fopen(ruta, 'rb');
  if fid < 0, error('No se pudo leer %s', ruta); endif
  unwind_protect
    bytes = fread(fid, Inf, 'uint8=>uint8');
  unwind_protect_cleanup
    fclose(fid);
  end_unwind_protect
  h = lower(hash('sha256', char(bytes(:).')));
endfunction

function s = sanitizar_hash_local(rel)
  s = regexprep(rel, '[^A-Za-z0-9_]', '_');
  if isempty(s) || ~isletter(s(1)), s = ['f_' s]; endif
endfunction

function lista = leer_lista_local(ruta)
  lista = {};
  fid = fopen(ruta, 'rt');
  if fid < 0, error('No se pudo abrir %s', ruta); endif
  unwind_protect
    while true
      linea = fgetl(fid);
      if ~ischar(linea), break; endif
      linea = strtrim(linea);
      if ~isempty(linea) && linea(1) ~= '#'
        lista{end+1} = linea;
      endif
    endwhile
  unwind_protect_cleanup
    fclose(fid);
  end_unwind_protect
endfunction

function respaldar_local(origen, destino)
  asegurar_carpeta_local(fileparts(destino));
  [cp_ok, cp_msg] = copyfile(origen, destino, 'f');
  if ~cp_ok, error('No se pudo respaldar %s (%s)', origen, cp_msg); endif
endfunction

function asegurar_carpeta_local(carpeta)
  if isempty(carpeta), return; endif
  if exist(carpeta, 'dir') ~= 7
    [mk_ok, mk_msg] = mkdir(carpeta);
    if ~mk_ok, error('No se pudo crear %s (%s)', carpeta, mk_msg); endif
  endif
endfunction

function restaurar_local(root, backup, nuevos, copiar)
  for i = 1:numel(nuevos)
    if exist(nuevos{i}, 'file') == 2
      delete(nuevos{i});
    endif
  endfor
  for i = 1:numel(copiar)
    rel = copiar{i};
    src = fullfile(backup, rel);
    dst = fullfile(root, rel);
    if exist(src, 'file') == 2
      asegurar_carpeta_local(fileparts(dst));
      copyfile(src, dst, 'f');
    endif
  endfor
endfunction

function ruta = canon_local(ruta)
  if ~ischar(ruta) || isempty(ruta), return; endif
  [estado, salida] = system(sprintf('readlink -f "%s" 2>/dev/null', ...
    strrep(ruta, '"', '\\"')));
  if estado == 0 && ischar(salida) && ~isempty(strtrim(salida))
    ruta = strtrim(salida);
  else
    ruta = strrep(ruta, '\\', '/');
    while ~isempty(strfind(ruta, '//')), ruta = strrep(ruta, '//', '/'); endwhile
  endif
endfunction
